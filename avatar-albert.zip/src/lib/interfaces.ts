export interface Agent {
  id: string;
  name: string;
  description: string;
  is_running: boolean;
}
